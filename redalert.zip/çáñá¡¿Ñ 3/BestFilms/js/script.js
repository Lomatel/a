// 1. БУРГЕР-МЕНЮ
let burger = document.querySelector('.burger');
let nav = document.querySelector('.nav');

if (burger && nav) {
    burger.onclick = function() {
        nav.classList.toggle('show');
        this.innerHTML = nav.classList.contains('show') ? '✕' : '☰';
    };
}

// 2. СЛАЙДЕР
let slideIndex = 0;
let slides = document.querySelectorAll('.slide');
let dots = document.querySelectorAll('.dot');

function showSlide(n) {
    if (n >= slides.length) slideIndex = 0;
    if (n < 0) slideIndex = slides.length - 1;
    
    slides.forEach(s => s.classList.remove('active'));
    dots.forEach(d => d.classList.remove('active'));
    
    if (slides[slideIndex]) {
        slides[slideIndex].classList.add('active');
        dots[slideIndex].classList.add('active');
    }
}

// Кнопки слайдера
let nextBtn = document.querySelector('.slider-next');
let prevBtn = document.querySelector('.slider-prev');

if (nextBtn) nextBtn.onclick = () => { slideIndex++; showSlide(slideIndex); };
if (prevBtn) prevBtn.onclick = () => { slideIndex--; showSlide(slideIndex); };

// Точки слайдера
dots.forEach((dot, i) => {
    dot.onclick = () => { slideIndex = i; showSlide(slideIndex); };
});

// Автопрокрутка
setInterval(() => {
    slideIndex++;
    showSlide(slideIndex);
}, 5000);

// 3. ТЕМА
let themeToggle = document.querySelector('#themeToggle');
let savedTheme = localStorage.getItem('theme') || 'dark';

// Устанавливаем сохраненную тему
if (savedTheme === 'light') {
    document.documentElement.setAttribute('data-theme', 'light');
    if (themeToggle) themeToggle.checked = true;
}

// Обработка переключения
if (themeToggle) {
    themeToggle.onchange = function() {
        if (this.checked) {
            document.documentElement.setAttribute('data-theme', 'light');
            localStorage.setItem('theme', 'light');
        } else {
            document.documentElement.setAttribute('data-theme', 'dark');
            localStorage.setItem('theme', 'dark');
        }
    };
}

// 4. ФИЛЬТРЫ В КАТАЛОГЕ
let filterBtn = document.querySelector('.filter-toggle');
let filters = document.querySelector('.filters');

if (filterBtn && filters) {
    filterBtn.onclick = function() {
        filters.classList.toggle('mobile-hidden');
        this.innerHTML = filters.classList.contains('mobile-hidden') ? 'Фильтры ▼' : 'Скрыть ▲';
    };
}

// 5. ВАЛИДАЦИЯ ФОРМ
let forms = document.querySelectorAll('form');
forms.forEach(form => {
    form.onsubmit = function(e) {
        let valid = true;
        
        // Проверяем обязательные поля
        this.querySelectorAll('[required]').forEach(input => {
            if (!input.value.trim()) {
                input.style.borderColor = 'red';
                valid = false;
            } else {
                input.style.borderColor = '';
            }
        });
        
        // Проверяем пароли
        let pass = this.querySelector('input[type="password"]');
        let pass2 = this.querySelector('input[name*="confirm"], input[placeholder*="повтор"]');
        
        if (pass && pass2 && pass.value !== pass2.value) {
            pass2.style.borderColor = 'red';
            valid = false;
        }
        
        if (!valid) {
            e.preventDefault();
            alert('Заполните все поля правильно!');
        } else {
            alert('Успешно!');
        }
    };
});

// 6. КЛИК ПО КАРТОЧКЕ → КАТАЛОГ
let cards = document.querySelectorAll('.card');
cards.forEach(card => {
    card.onclick = function(e) {
        if (!e.target.closest('a')) {
            window.location.href = 'catalog.html';
        }
    };
});

// 7. ИНИЦИАЛИЗАЦИЯ ПРИ ЗАГРУЗКЕ
window.onload = function() {
    // Звёзды рейтинга
    document.querySelectorAll('.rating').forEach(rating => {
        let stars = Math.floor(Math.random() * 3) + 3; // 3-5 звёзд
        let html = '';
        
        for (let i = 1; i <= 5; i++) {
            html += i <= stars ? '★' : '☆';
        }
        
        rating.innerHTML = html;
    });
};