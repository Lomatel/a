import { useRef, useState } from 'react'

function Board({ b, i, boards, setBoards, fullscreenBoard, setFullscreenBoard }) {
    const addLike = async (e) => {
        const clone = window.structuredClone(boards);
        clone.find(c => c.id === b.id).nLikes += 1;
        setBoards(clone);
        await fetch('http://localhost:3000/like/1', { method: 'post' });
    };

    return (
        <div
            key={i} 
            className={`boards__board ${fullscreenBoard === i ? 'fullscreen' : ''}`}
            onClick={() => setFullscreenBoard(i)}
        >
            <button className="boards__like" onClick={addLike}>Лайк {b.nLikes}</button>
            {b.objects.map(o => {
                const Tag = o.tag;
                const style = { 
                    width: o.width + '%', 
                    height: o.height + '%',
                    top: o.top + '%', 
                    left: o.left + '%' 
                };
                
                if (o.backgroundColor) style.backgroundColor = o.backgroundColor;
                if (o.border) style.border = o.border;
                
                const props = {
                  style: style
                };
                
                if (o.tag === 'img' && o.src) {
                  props.src = new URL('../assets/' + o.src, import.meta.url).href;
                }
                
                if (o.text) {
                  return <Tag key={o.id} {...props}>{o.text}</Tag>;
                }
                
                return <Tag key={o.id} {...props} />;
              })}
              
              {fullscreenBoard === i && (
                <button 
                  className="close-btn"
                  onClick={(e) => {
                    e.stopPropagation();
                    setFullscreenBoard(null);
                  }}
                >
                  ×
                </button>
              )}
            </div>
    )
}

export default Board;