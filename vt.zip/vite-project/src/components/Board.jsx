import { useRef } from 'react';
import { socket } from '../global.js';

function Board({ b, i, boards, setBoards, fullscreenBoard, setFullscreenBoard }) {
    const isDown = useRef(false);
    const offsetTopStart = useRef(0);
    const offsetLeftStart = useRef(0);
    const boardDiv = useRef(null);

    const addLike = async (e) => {
        e.stopPropagation();
        const clone = window.structuredClone(boards);
        clone.find(c => c.id === b.id).nLikes += 1;
        setBoards(clone);
        await fetch('http://localhost:3000/like/' + b.id, { method: 'post' });
    };
    // Начало перетаскивания
    function saveStartValues(e, o) {
      e.target.setPointerCapture(e.pointerId);
      isDown.current = true;
      offsetTopStart.current = o.top - e.clientY / boardDiv.current.offsetHeight * 100;
      offsetLeftStart.current = o.left - e.clientX / boardDiv.current.offsetWidth * 100;
    }
    // Перетаскивание
    function move(e, i) {
      if (isDown.current) {
        const clone = window.structuredClone(boards);
        const curClone = clone.find(c => c.id === b.id);
        const yPercent = e.clientY / boardDiv.current.offsetHeight * 100;
        const xPercent = e.clientX / boardDiv.current.offsetWidth * 100;

        if (xPercent - curClone.objects[i].left < 10) {
          curClone.objects[i].width += curClone.objects[i].left -
            (e.clientX - boardDiv.current.offsetLeft) / boardDiv.current.offsetWidth * 100;
          // Отправляем данные в реальном времени
          socket.send(JSON.stringify({ key: 'width', val: curClone.objects[i].width }));
        }
        else if (yPercent - curClone.objects[i].top < 10) {
          curClone.objects[i].height += curClone.objects[i].top -
            (e.clientY - boardDiv.current.offsetTop) / boardDiv.current.offsetHeight * 100;
          socket.send(JSON.stringify({ key: 'height', val: curClone.objects[i].height }));
        }
        else {
          curClone.objects[i].top = offsetTopStart.current + yPercent;
          curClone.objects[i].left = offsetLeftStart.current + xPercent;
          socket.send(JSON.stringify({ key: 'top', val: curClone.objects[i].top }));
        }
        setBoards(clone);
      }
    }

    return (
        <div
            ref={boardDiv}
            key={i} 
            className={`boards__board ${fullscreenBoard === i ? 'fullscreen' : ''}`}
            onClick={() => setFullscreenBoard(i)}
        >
            <button className="boards__like" onClick={addLike}>Лайк {b.nLikes}</button>
            {b.objects.map((o, i) => {
                const Tag = o.tag;
                const style = { 
                    width: o.width + '%', 
                    height: o.height + '%',
                    top: o.top + '%', 
                    left: o.left + '%' 
                };
                
                if (o.backgroundColor) style.backgroundColor = o.backgroundColor;
                if (o.border) style.border = o.border;
                
                const props = {
                  style: style
                };
                
                if (o.tag === 'img' && o.src) {
                  props.src = new URL('../assets/' + o.src, import.meta.url).href;
                }
                
                  return <Tag
                    key={o.id}
                    {...props}
                    onDragStart={e => e.preventDefault()}
                    onPointerDown={e => saveStartValues(e, o)}
                    onPointerMove={e => move(e, i)}
                    onPointerUp={() => isDown.current = false}
                  >
                    {o.text}
                  </Tag>;
              })}
              
              {fullscreenBoard === i && (
                <button 
                  className="close-btn"
                  onClick={(e) => {
                    e.stopPropagation();
                    setFullscreenBoard(null);
                  }}
                >
                  ×
                </button>
              )}
            </div>
    )
}

export default Board;
