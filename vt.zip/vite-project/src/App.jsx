import { useEffect, useState } from 'react';
import { socket } from './global.js';
import Auth from './components/Auth';
import Board from './components/Board';

function App() {
  const [boards, setBoards] = useState([]);
  
  const [showAuth, setShowAuth] = useState(true);
  const [fullscreenBoard, setFullscreenBoard] = useState(null);

  useEffect(() => {
    // Получение данных в реальном времени
    socket.addEventListener('message', (event) => {
      //console.log('Message from server: ', JSON.parse(event.data));
    });
    (async () => {
      const res = await fetch('http://localhost:3000/1').then(r => r.json());
      setBoards(res);
    })();
  }, []);

  const closeFullscreen = () => {
    setFullscreenBoard(null);
  };
  
  const addObject = (newObj) => {
    const clone = window.structuredClone(boards);
    clone[fullscreenBoard].objects.push({ id: clone[fullscreenBoard].objects.at(-1).id + 1, ...newObj });
    setBoards(clone);
  }

  return (
    <>
      {showAuth && <Auth setShowAuth={setShowAuth} />}
      <main className="main">
        <section className="boards">
          {fullscreenBoard !== null && <div className="boards__btns">
            <button className="boards__btn" onClick={e => addObject(
              { tag: 'p', text: 'ADDED', top: 1, left: 1 })}>Текст</button>
            <input
              className="boards__btn"
              type="file"
              onChange={e => addObject(
                { tag: 'img', src: e.target.files[0].name, width: 10, height: 10, top: 1, left: 1 })}
            />
            <button className="boards__btn" onClick={e => addObject(
              { 
                tag: 'div', 
                width: 10, 
                height: 10, 
                top: 1, 
                left: 1,
                backgroundColor: '#f0f0f0',
                border: '1px solid #ccc'
              })}>Квадрат</button>
          </div>}
          {boards.map((b, i) => <Board
            key={b.id}
            b={b}
            i={i}
            boards={boards}
            setBoards={setBoards}
            fullscreenBoard={fullscreenBoard}
            setFullscreenBoard={setFullscreenBoard}
          />)}
        </section>
      </main>
    </>
  )
}

export default App;
