 export const socket = new WebSocket('ws://localhost:3000');
