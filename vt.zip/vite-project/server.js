import { readFileSync, writeFileSync } from 'node:fs';
import { join, parse } from 'node:path';
import { createServer } from 'node:http';
import express, { json } from 'express';
import { WebSocketServer, WebSocket } from 'ws';
import cors from 'cors';

const app = express();
const server = createServer(app);
const wss = new WebSocketServer({ server });
app.use(json());
app.use(cors({ origin: '*' }));

const users = JSON.parse(readFileSync('users.json', 'utf8'));
const boards = JSON.parse(readFileSync('boards.json', 'utf8'));

app.get('/:id', (req, res) => {
  const user = users.find(u => u.id == req.params.id);
  res.json(user.boardsIds.map(id => boards.find(b => b.id === id)));
});
app.post('/signin', (req, res) => {
  const user = users.find(u => u.email === req.body.email);
  if (user && user.password === req.body.password)
    res.status(200).json(user);
  else
    res.sendStatus(404);
});
app.post('/signup', (req, res) => {
  if (users.some(u => u.email === req.body.email))
    res.sendStatus(409);
  else {
    users.push(req.body);
    res.status(201).json(users.at(-1));
  }
});
app.post('/like/:id', (req, res) => {
  const board = boards.find(b => b.id == req.params.id);
  board.nLikes += 1;
  writeFileSync('boards.json', JSON.stringify(boards));
});

wss.on('connection', (ws) => {
  ws.on('message', (data) => {
    const parsed = JSON.parse(data);
    //const board = boards.find(b => b.id === parsed.id);
    //board[parsed.key] = parsed.val;
    //writeFileSync('boards.json', JSON.stringify(boards));
    wss.clients.forEach(c => {
      if (c.readyState === WebSocket.OPEN)
        c.send(data.toString());
    });
  });
});

server.listen(3000, () => console.log('Сервер localhost:3000'));

