<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title', 'Мой Сайт'); ?></title>
</head>
<body>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
</body>
</html><?php /**PATH /home/upcast/Downloads/lv/resources/views/app.blade.php ENDPATH**/ ?>