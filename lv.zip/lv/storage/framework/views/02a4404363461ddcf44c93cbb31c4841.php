<?php $__env->startSection('title', 'Вход в админ-панель'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Админ-панель</h1>
    <h2>Курсы</h2>
    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><?php echo e($c->name); ?></p>
        <p><?php echo e($c->content); ?></p>
        <p><?php echo e($c->description); ?></p>
        <p><?php echo e($c->duration); ?></p>
        <p><?php echo e($c->price); ?></p>
        <p><?php echo e($c->starts_at); ?></p>
        <p><?php echo e($c->ends_at); ?></p>
        <p><?php echo e($c->cover_path); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/upcast/Downloads/lv/resources/views/admin/index.blade.php ENDPATH**/ ?>