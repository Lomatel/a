<?php $__env->startSection('title', 'Курсы'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Курсы</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/upcast/Downloads/lv/resources/views/courses/index.blade.php ENDPATH**/ ?>