<?php $__env->startSection('title', 'Вход в админ-панель'); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(url('/course-admin/auth')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <h2>Админ-панель</h2>
        <?php if($errors->any()): ?>
            <div class="error">
                <?php echo e($errors->first()); ?>

            </div>
        <?php endif; ?>
        <div>
            <label>Email:</label>
            <input type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
        </div>
        <div>
            <label>Пароль:</label>
            <input type="password" name="password" required>
        </div>
        <button type="submit">Войти</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/upcast/Downloads/lv/resources/views/admin/login.blade.php ENDPATH**/ ?>