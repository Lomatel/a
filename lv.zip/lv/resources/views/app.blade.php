<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>@yield('title', 'Мой Сайт')</title>
</head>
<body>
    <main>
        @yield('content')
    </main>
</body>
</html>