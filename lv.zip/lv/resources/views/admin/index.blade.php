@extends('app')
@section('title', 'Вход в админ-панель')

@section('content')
    <h1>Админ-панель</h1>
    <h2>Курсы</h2>
    @foreach ($courses as $c)
        <p>{{ $c->name }}</p>
        <p>{{ $c->content }}</p>
        <p>{{ $c->description }}</p>
        <p>{{ $c->duration }}</p>
        <p>{{ $c->price }}</p>
        <p>{{ $c->starts_at }}</p>
        <p>{{ $c->ends_at }}</p>
        <p>{{ $c->cover_path }}</p>
    @endforeach
@endsection