@extends('app')
@section('title', 'Вход в админ-панель')

@section('content')
    <form action="{{ url('/course-admin/auth') }}" method="POST">
        @csrf
        <h2>Админ-панель</h2>
        @if ($errors->any())
            <div class="error">
                {{ $errors->first() }}
            </div>
        @endif
        <div>
            <label>Email:</label>
            <input type="email" name="email" value="{{ old('email') }}" required autofocus>
        </div>
        <div>
            <label>Пароль:</label>
            <input type="password" name="password" required>
        </div>
        <button type="submit">Войти</button>
    </form>
@endsection
