<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Lesson extends Model
{
    protected static function booted()
    {
        static::creating(function ($lesson) {
            $n = self::where('course_id', $lesson->course_id)->count();
            if ($n > 5)
                throw new Exception("Ошибка: Для одного поста разрешено не более 5 комментариев.");
            if (!filter_var($lesson->link, FILTER_VALIDATE_URL))
                throw new Exception("Ошибка: Поле 'link' должно быть корректным URL-адресом.");
        });
    }

    public function course()
    {
        return $this->belongsTo(Course::class);
    }
}
