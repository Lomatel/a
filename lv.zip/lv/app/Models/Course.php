<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Course extends Model
{
    protected $fillable = [
        'name', 
        'duration', 
        'price', 
        'starts_at', 
        'ends_at', 
        'cover_path'
    ];
    public function lessons()
    {
        return $this->hasMany(Lesson::class);
    }
    public function students()
    {
        return $this->hasMany(Student::class);
    }
}
