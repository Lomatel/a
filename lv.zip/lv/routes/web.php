<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;

Route::get('/', function () {
    return view('admin.login');
});
Route::get('/course-admin/auth', [AdminController::class, 'showLogin'])->name('admin.login');
Route::post('/course-admin/auth', [AdminController::class, 'login']);
Route::get('/course-admin', [AdminController::class, 'index'])->name('admin');
