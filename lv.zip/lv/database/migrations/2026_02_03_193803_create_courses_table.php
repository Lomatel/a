<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('courses', function (Blueprint $table) {
            $table->id();
            $table->string('name', 30);
            $table->string('description', 100)->nullable();
            $table->unsignedTinyInteger('duration')->check('duration <= 10');
            $table->decimal('price', 16, 2)->check('price >= 100');
            $table->date('starts_at');
            $table->date('ends_at');
            $table->string('cover_path');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('courses');
    }
};
