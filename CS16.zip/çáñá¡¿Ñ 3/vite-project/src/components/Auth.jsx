import { useRef, useState } from 'react'

function Auth({ setShowAuth }) {
    const email = useRef(null);
    const login = useRef(null);
    const password = useRef(null);
    const [action, setAction] = useState('signin');

    async function send(e) {
        e.preventDefault();
        setShowAuth(false);
        /*await fetch('http://localhost:3000/' + action, {
            method: 'post',
            body: { email: email.current.value, login: login.current.value, password: password.current.value },
        });*/
    }

    return (
        <>
            <form action="" className='form' onSubmit={send}>
                <fieldset className='row'>
                    <button className='form__btn' type="button" onClick={() => setAction('signin')}>Вход</button>
                    <button className='form__btn' type="button" onClick={() => setAction('signup')}>Регистрация</button>
                </fieldset>
                <fieldset><input ref={email} type="emall" className="input" placeholder="Почта" /></fieldset>
                {action === 'signup' && <fieldset><input ref={login} type="text" className="input" placeholder="Логин" /></fieldset>}
                <fieldset><input ref={password} type="password" className="input" placeholder="Пароль" /></fieldset>
                <button>Отправка</button>
            </form>
        </>
    )
}

export default Auth;